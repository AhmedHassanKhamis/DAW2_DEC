/* ---------------------------------------
Pon aquí tu nombre y apellido, por favor.


------------------------------------------*/


/*
* Se pueden utilizar los formatos de las correspondientes resultados de los diferentes pasos.
* Se encuentran en datos.js y, en cada paso pertinente, se indica la variable correspondiente
* Si se utiliza alguna de esas variables, en el apartado correspondiente a su generación,
* se tendrá un 0
*/


/*
++ salida en la variable salP1 de datos.js 
*/
function tratarDatosEntrada(cadena, sepLinea, sepCampos) {}


function aObjeto(array,nomCampos) {}


/*
++ salida en la variable salP3 
*/
function filtarPorFecha(array, campo, fecha) {}



function objetosConCampos(arrayObj, campos) {}


/*
++ salida en la variable salP5 
*/
function realizarTablaIncidencias(arrayObj) {
  // Las fórmulas son:

  // Para 7 días
  // Si hay un valor en cases_PCR_7days, utilizarlo. Si no, utilizar el valor de cases_7days
  // La incidencia se calcula con el valor anterior dividido entre la población y multiplicado por 1000000

  // Para 14 días
  // Si hay un valor en cases_PCR_14days, utilizarlo. Si no, utilizar el valor de cases_14days
  // La incidencia se calcula con el valor anterior dividido entre la población y multiplicado por 1000000

}


function crearTablaHTML(arrayObj) {
/*
  table
    caption 
    thead
      tr
        th
    tbody
      tr
        td
    tfoot
      tr
        td
*/

}

