'use strict';

/* Estructura del html

  (4) en el id=act
   El nombre de la imagen se forma con las tres primeras letras
   del valor del campo cielo (en minúsculas) + la terminación svg

<div>
  <h2>Madrid</h2>
  <h3>(España)</h3>
  <p>Actualizado hace <span id="act">1</span> minuto(s)</p>
</div>
<div data-date="25/2/2021">
  <h3>Hoy</h3>
  <img src="img/sol.svg" alt="estado">
  <span>Soleado</span>
  <p>Min: 1,6°</p>
  <p>Max: 13,5°</p>
</div>
*/

// El codigo de la tecla ENTER es 13

// Variables y funciones a utilizar obligatoriamente dentro del IIFE
let urlServidor = 'http://localhost:3000';

/*
** Función para pedir los datos al servidor CORS
** El GET se debe hacer a URL
*/
function pedirDatos(peticion, callback)  {
  const URL = urlServidor + peticion;

}

